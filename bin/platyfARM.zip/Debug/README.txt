-player
WASD - movement
left click - use current item
right click - interact with object
mouse wheel - scroll item toolbar
E - inventory
F - crafting
C - character menu

-dialog
Enter/left click - select dialog option
mouse wheel - scroll dialog option

